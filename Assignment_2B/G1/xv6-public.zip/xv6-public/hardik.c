# include "types.h"
# include "stat.h"
# include "user.h"
# include "fcntl.h"
int main(int argc, char** argv){

	// int x1 = 74;
	// int x2 = 90;
	// int x3 = 11;
	// fork();
	// int val = wait2(&x1, &x2, &x3);
	// printf(1, "Child which we waited for: %d \n", val);
	// exit();

	// now only the parent process is running
	cps();

	for(int i = 0; i<3 ; i++){
		// if it's here it must be the parent only
		int pid = fork();
		if(pid<0){
			printf(1, "@");
			exit();
		}else if(pid>0){
			// still in the parent
			continue;
		}else{
			// in the child now
			double x = 0.0;
			double y = 1.2;
			for(double z = 0.0; z<80.0 ; z++) x+= 3.14 * y;
			printf(1, "(");
			yield();
			exit();
		}
	}
	// if it's here it must be parent, and done with creating all the three children 
	// now would be a good time to look at the state
	// cps();
	for(int i = 0; i<3 ; i++) wait();
	exit(); // exits the parent
}
